"use strict";
/**
 * Copyright 2024 IBN Network (ICTU Blockchain Network)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.contracts = exports.TeaTraceContract = void 0;
var teaTraceContract_1 = require("./teaTraceContract");
Object.defineProperty(exports, "TeaTraceContract", { enumerable: true, get: function () { return teaTraceContract_1.TeaTraceContract; } });
Object.defineProperty(exports, "contracts", { enumerable: true, get: function () { return teaTraceContract_1.contracts; } });
//# sourceMappingURL=index.js.map